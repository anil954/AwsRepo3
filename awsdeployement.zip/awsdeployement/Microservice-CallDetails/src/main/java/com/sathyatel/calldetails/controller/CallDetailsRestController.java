package com.sathyatel.calldetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.calldetails.DTO.CallDetailsDTO;
import com.sathyatel.calldetails.service.impl.CallDetailsServiceImpl;

@RestController
public class CallDetailsRestController {
	
	@Autowired
	CallDetailsServiceImpl service;
	
	@GetMapping(value= "/{phoneNumber}", produces="application/json")
	public List<CallDetailsDTO> getCallDetailsByPhoneNumber(@PathVariable("phoneNumber") Long calledBy){
		//Path variable annotation is used to bind the parameter of the handler
		return service.getCallDetailsByPhoneNumber(calledBy);
		
	}
	
 }